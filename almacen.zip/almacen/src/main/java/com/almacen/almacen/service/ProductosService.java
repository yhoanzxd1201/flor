package com.almacen.almacen.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.almacen.almacen.models.Productos;
//service para poner los metodos abstractos q se van a utilizar en el service implemnet , administra los metodos
@Service
public interface ProductosService {

    public List<Productos> listarProductos();
}
