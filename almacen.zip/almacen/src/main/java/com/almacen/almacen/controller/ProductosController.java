package com.almacen.almacen.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.almacen.almacen.service.ProductosService;

//permite hacer las poeticiones de la pagina html 
@Controller
public class ProductosController {

    @Autowired
    private ProductosService service;
//peticiones que haces al HTML , mostrar , subir actualizar , etc
    @GetMapping("/productos")
    public String mostrarProductos(Model model) {
        //va hacer referencia a todo lo que se llame productos y va hacer la funcion que le pide (explicacion dudosa)
        model.addAttribute("productos", service.listarProductos());
        return "productos";
    }
}
