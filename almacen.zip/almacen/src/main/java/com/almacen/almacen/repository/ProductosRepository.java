package com.almacen.almacen.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.almacen.almacen.models.Productos;
//IDENTIFICA COMO SE VA UTILIZAR, HEREDA DE JPA QUE TIENE METODOS PARA TRABAJAR CON LA BASE DE DATOS...CLASE Y TIPO DE I
@Repository
public interface ProductosRepository extends JpaRepository<Productos,Integer >{

}
