package com.almacen.almacen.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;


//te dice que esa clase va se una tabla en la base de datos
@Entity
public class Productos {
//que va ser el id la clave primaria y lo siguiente para que incremente 
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private int codigo;
    private String descripcion;
    //aclara el nombre porque en la base de datos se escribe con guion la separacion
    @Column(name="precio_unitario")
    private double precioUnitario;
    private int stock;

    public Productos(int codigo, String descripcion, Integer id, double precioUnitario, int stock) {
        this.codigo = codigo;
        this.descripcion = descripcion;
        this.id = id;
        this.precioUnitario = precioUnitario;
        this.stock = stock;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(double precioUnitario) {
        this.precioUnitario = precioUnitario;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }



}
