package com.almacen.almacen.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.almacen.almacen.models.Productos;
import com.almacen.almacen.repository.ProductosRepository;

public class ProductosServiceImp implements ProductosService {
//autowired dice q de otra clase va traer la clase sin instanciar un objeto
    @Autowired
    private ProductosRepository repositorio;
    @Override
    public List<Productos> listarProductos() {
    return repositorio.findAll();
    }

}
